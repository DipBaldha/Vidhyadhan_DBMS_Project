README

1. ERD.pdf Entity Relationship Diagram

2. Relation_Schema.pdf 

3. DDL.txt - Data-Defination Language Script

4. DATA_INSERTION.txt text file Containing SQL Data Insertion Script

5. Queries.txt text file Containing Queries


